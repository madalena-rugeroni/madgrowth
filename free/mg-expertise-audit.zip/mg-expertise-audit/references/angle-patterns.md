# How inventory answers combine into angles

An angle = who + problem + proof + what it would be. Use these patterns to draft quickly; then sharpen with the founder's specifics.

## By "the repeat" × "the room"
| Repeat | Room: founders / CEOs | Room: VPs / directors | Room: the team | Room: customers |
|---|---|---|---|---|
| Built a function from zero | fractional leader for that function at seed–A (b2b-services) | playbook / productized build (b2b-services, productizer) | training or a course for that function (media-audience / b2c digital) | rare — usually a product idea (b2b-saas) |
| Fixed something broken | the diagnostic / audit offer (b2b-services, advisor) | interim or turnaround engagement (b2b-services) | a tool that prevents the break (b2b-saas) | — |
| Scaled something that worked | advisory retainer on the scaling problem (b2b-services) | the "second-time" playbook (productized) | the system as software (b2b-saas, venture builder) | consumer version of the thing (b2c-product) |
| Led a transition | the transition specialist — reorg, launch, market entry (b2b-services) | same, productized as a sprint | a community of people going through it (media-audience) | — |

## By "the pull"
- **Make the complicated clear** → content, teaching, media; the Broadcaster lane. Angle shape: "[audience] who need to understand [domain] — explained by someone who ran it."
- **Make a hard call** → advisory, judgment-priced; the Advisor lane. Angle shape: "[buyer] facing [decision] — I've made it N times."
- **Get it shipped** → productized delivery, sprints; the Productizer lane. Angle shape: "[outcome] in [timebox], fixed price."
- **Fix the process** → operations, systems, tooling; the Orchestrator / Venture Builder lane. Angle shape: "[function] that runs without the founder — built or automated."

## By "money shape"
- A few clients paying properly → b2b-services, advisor / solo.
- Many paying a little → media-audience or b2c-product digital; needs a Broadcaster or Productizer.
- A product sold while you sleep → b2c digital or b2b-saas; needs build capacity or a partner.
- A mix → the funnel pattern: media → productized → advisory (route by the first line they'd build).

## Refusals override everything
- Won't be public → no media-audience angle; content-light services or software only.
- Won't take client calls → no services angle; products or software.
- Won't build software → no b2b-saas unless there's a partner; say so.
- Won't manage people → solo shapes only; no agency / Orchestrator angles.

## Proof strength (for ranking)
A number with a named context ("grew pipeline from €2M to €11M at X") > a number without context > a role without a number > "I'm good at it". Angles with no number rank last regardless of appeal — the roast will kill them anyway.

## Alternative option sets (if the founder picked "none")
Repeat: turned around a team · opened a market · replaced a vendor/tool · ran a P&L. Pull: to negotiate · to hire · to write the doc · to say no. Room: investors · partners · regulators · press.
